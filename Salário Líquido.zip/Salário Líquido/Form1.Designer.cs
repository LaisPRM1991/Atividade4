﻿
namespace Salário_Líquido
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtBFuncionario = new System.Windows.Forms.TextBox();
            this.lblFuncionario = new System.Windows.Forms.Label();
            this.lblSalarioBruto = new System.Windows.Forms.Label();
            this.lblNumFilhos = new System.Windows.Forms.Label();
            this.grpBSexo = new System.Windows.Forms.GroupBox();
            this.rdBtnFeminino = new System.Windows.Forms.RadioButton();
            this.rdBtnMasculino = new System.Windows.Forms.RadioButton();
            this.ckBCasado = new System.Windows.Forms.CheckBox();
            this.lblDados = new System.Windows.Forms.Label();
            this.grpBResultados = new System.Windows.Forms.GroupBox();
            this.lblINSS = new System.Windows.Forms.Label();
            this.lblIRPF = new System.Windows.Forms.Label();
            this.lblSalarioFamilia = new System.Windows.Forms.Label();
            this.lblSalarioLiquido = new System.Windows.Forms.Label();
            this.txtBINSS = new System.Windows.Forms.TextBox();
            this.txtBIRPF = new System.Windows.Forms.TextBox();
            this.txtSalarioFamilia = new System.Windows.Forms.TextBox();
            this.txtSalarioLiquido = new System.Windows.Forms.TextBox();
            this.lblDescontoINSS = new System.Windows.Forms.Label();
            this.lblDescontoIRPF = new System.Windows.Forms.Label();
            this.txtBDescontoINSS = new System.Windows.Forms.TextBox();
            this.txtBDescontoIRPF = new System.Windows.Forms.TextBox();
            this.grpBCasado = new System.Windows.Forms.GroupBox();
            this.mTxtBSalarioBruto = new System.Windows.Forms.MaskedTextBox();
            this.cmBNumFilhos = new System.Windows.Forms.ComboBox();
            this.btnVerifica = new System.Windows.Forms.Button();
            this.grpBSexo.SuspendLayout();
            this.grpBResultados.SuspendLayout();
            this.grpBCasado.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtBFuncionario
            // 
            this.txtBFuncionario.Location = new System.Drawing.Point(173, 42);
            this.txtBFuncionario.Name = "txtBFuncionario";
            this.txtBFuncionario.Size = new System.Drawing.Size(164, 20);
            this.txtBFuncionario.TabIndex = 0;
            // 
            // lblFuncionario
            // 
            this.lblFuncionario.AutoSize = true;
            this.lblFuncionario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFuncionario.Location = new System.Drawing.Point(32, 42);
            this.lblFuncionario.Name = "lblFuncionario";
            this.lblFuncionario.Size = new System.Drawing.Size(132, 16);
            this.lblFuncionario.TabIndex = 1;
            this.lblFuncionario.Text = "Nome do funcionário";
            // 
            // lblSalarioBruto
            // 
            this.lblSalarioBruto.AutoSize = true;
            this.lblSalarioBruto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalarioBruto.Location = new System.Drawing.Point(32, 83);
            this.lblSalarioBruto.Name = "lblSalarioBruto";
            this.lblSalarioBruto.Size = new System.Drawing.Size(85, 16);
            this.lblSalarioBruto.TabIndex = 2;
            this.lblSalarioBruto.Text = "Salário Bruto";
            // 
            // lblNumFilhos
            // 
            this.lblNumFilhos.AutoSize = true;
            this.lblNumFilhos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumFilhos.Location = new System.Drawing.Point(32, 119);
            this.lblNumFilhos.Name = "lblNumFilhos";
            this.lblNumFilhos.Size = new System.Drawing.Size(109, 16);
            this.lblNumFilhos.TabIndex = 3;
            this.lblNumFilhos.Text = "Número de filhos";
            // 
            // grpBSexo
            // 
            this.grpBSexo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.grpBSexo.Controls.Add(this.rdBtnMasculino);
            this.grpBSexo.Controls.Add(this.rdBtnFeminino);
            this.grpBSexo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBSexo.Location = new System.Drawing.Point(427, 42);
            this.grpBSexo.Name = "grpBSexo";
            this.grpBSexo.Size = new System.Drawing.Size(200, 100);
            this.grpBSexo.TabIndex = 7;
            this.grpBSexo.TabStop = false;
            this.grpBSexo.Text = "Sexo";
            // 
            // rdBtnFeminino
            // 
            this.rdBtnFeminino.AutoSize = true;
            this.rdBtnFeminino.Checked = true;
            this.rdBtnFeminino.Location = new System.Drawing.Point(59, 32);
            this.rdBtnFeminino.Name = "rdBtnFeminino";
            this.rdBtnFeminino.Size = new System.Drawing.Size(34, 20);
            this.rdBtnFeminino.TabIndex = 0;
            this.rdBtnFeminino.TabStop = true;
            this.rdBtnFeminino.Text = "F";
            this.rdBtnFeminino.UseVisualStyleBackColor = true;
            // 
            // rdBtnMasculino
            // 
            this.rdBtnMasculino.AutoSize = true;
            this.rdBtnMasculino.Location = new System.Drawing.Point(59, 61);
            this.rdBtnMasculino.Name = "rdBtnMasculino";
            this.rdBtnMasculino.Size = new System.Drawing.Size(37, 20);
            this.rdBtnMasculino.TabIndex = 1;
            this.rdBtnMasculino.Text = "M";
            this.rdBtnMasculino.UseVisualStyleBackColor = true;
            // 
            // ckBCasado
            // 
            this.ckBCasado.AutoSize = true;
            this.ckBCasado.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ckBCasado.Location = new System.Drawing.Point(59, 35);
            this.ckBCasado.Name = "ckBCasado";
            this.ckBCasado.Size = new System.Drawing.Size(75, 20);
            this.ckBCasado.TabIndex = 8;
            this.ckBCasado.Text = "Casado";
            this.ckBCasado.UseVisualStyleBackColor = true;
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblDados.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDados.Location = new System.Drawing.Point(32, 244);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(90, 16);
            this.lblDados.TabIndex = 9;
            this.lblDados.Text = "lblMensagem";
            this.lblDados.Visible = false;
            // 
            // grpBResultados
            // 
            this.grpBResultados.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.grpBResultados.Controls.Add(this.txtBDescontoIRPF);
            this.grpBResultados.Controls.Add(this.txtBDescontoINSS);
            this.grpBResultados.Controls.Add(this.lblDescontoIRPF);
            this.grpBResultados.Controls.Add(this.lblDescontoINSS);
            this.grpBResultados.Controls.Add(this.txtSalarioLiquido);
            this.grpBResultados.Controls.Add(this.txtSalarioFamilia);
            this.grpBResultados.Controls.Add(this.txtBIRPF);
            this.grpBResultados.Controls.Add(this.txtBINSS);
            this.grpBResultados.Controls.Add(this.lblSalarioLiquido);
            this.grpBResultados.Controls.Add(this.lblSalarioFamilia);
            this.grpBResultados.Controls.Add(this.lblIRPF);
            this.grpBResultados.Controls.Add(this.lblINSS);
            this.grpBResultados.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grpBResultados.Location = new System.Drawing.Point(35, 285);
            this.grpBResultados.Name = "grpBResultados";
            this.grpBResultados.Size = new System.Drawing.Size(624, 210);
            this.grpBResultados.TabIndex = 10;
            this.grpBResultados.TabStop = false;
            // 
            // lblINSS
            // 
            this.lblINSS.AutoSize = true;
            this.lblINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblINSS.Location = new System.Drawing.Point(21, 31);
            this.lblINSS.Name = "lblINSS";
            this.lblINSS.Size = new System.Drawing.Size(91, 16);
            this.lblINSS.TabIndex = 11;
            this.lblINSS.Text = "Alíquota INSS";
            // 
            // lblIRPF
            // 
            this.lblIRPF.AutoSize = true;
            this.lblIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIRPF.Location = new System.Drawing.Point(21, 72);
            this.lblIRPF.Name = "lblIRPF";
            this.lblIRPF.Size = new System.Drawing.Size(90, 16);
            this.lblIRPF.TabIndex = 12;
            this.lblIRPF.Text = "Alíquota IRPF";
            // 
            // lblSalarioFamilia
            // 
            this.lblSalarioFamilia.AutoSize = true;
            this.lblSalarioFamilia.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalarioFamilia.Location = new System.Drawing.Point(21, 114);
            this.lblSalarioFamilia.Name = "lblSalarioFamilia";
            this.lblSalarioFamilia.Size = new System.Drawing.Size(98, 16);
            this.lblSalarioFamilia.TabIndex = 13;
            this.lblSalarioFamilia.Text = "Salário Família";
            // 
            // lblSalarioLiquido
            // 
            this.lblSalarioLiquido.AutoSize = true;
            this.lblSalarioLiquido.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalarioLiquido.Location = new System.Drawing.Point(21, 155);
            this.lblSalarioLiquido.Name = "lblSalarioLiquido";
            this.lblSalarioLiquido.Size = new System.Drawing.Size(98, 16);
            this.lblSalarioLiquido.TabIndex = 14;
            this.lblSalarioLiquido.Text = "Salário Líquido";
            // 
            // txtBINSS
            // 
            this.txtBINSS.Enabled = false;
            this.txtBINSS.Location = new System.Drawing.Point(122, 31);
            this.txtBINSS.Name = "txtBINSS";
            this.txtBINSS.Size = new System.Drawing.Size(164, 20);
            this.txtBINSS.TabIndex = 11;
            // 
            // txtBIRPF
            // 
            this.txtBIRPF.Enabled = false;
            this.txtBIRPF.Location = new System.Drawing.Point(122, 72);
            this.txtBIRPF.Name = "txtBIRPF";
            this.txtBIRPF.Size = new System.Drawing.Size(164, 20);
            this.txtBIRPF.TabIndex = 15;
            // 
            // txtSalarioFamilia
            // 
            this.txtSalarioFamilia.Enabled = false;
            this.txtSalarioFamilia.Location = new System.Drawing.Point(122, 114);
            this.txtSalarioFamilia.Name = "txtSalarioFamilia";
            this.txtSalarioFamilia.Size = new System.Drawing.Size(164, 20);
            this.txtSalarioFamilia.TabIndex = 16;
            // 
            // txtSalarioLiquido
            // 
            this.txtSalarioLiquido.Enabled = false;
            this.txtSalarioLiquido.Location = new System.Drawing.Point(122, 155);
            this.txtSalarioLiquido.Name = "txtSalarioLiquido";
            this.txtSalarioLiquido.Size = new System.Drawing.Size(164, 20);
            this.txtSalarioLiquido.TabIndex = 17;
            // 
            // lblDescontoINSS
            // 
            this.lblDescontoINSS.AutoSize = true;
            this.lblDescontoINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescontoINSS.Location = new System.Drawing.Point(341, 31);
            this.lblDescontoINSS.Name = "lblDescontoINSS";
            this.lblDescontoINSS.Size = new System.Drawing.Size(100, 16);
            this.lblDescontoINSS.TabIndex = 18;
            this.lblDescontoINSS.Text = "Desconto INSS";
            // 
            // lblDescontoIRPF
            // 
            this.lblDescontoIRPF.AutoSize = true;
            this.lblDescontoIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescontoIRPF.Location = new System.Drawing.Point(341, 72);
            this.lblDescontoIRPF.Name = "lblDescontoIRPF";
            this.lblDescontoIRPF.Size = new System.Drawing.Size(99, 16);
            this.lblDescontoIRPF.TabIndex = 19;
            this.lblDescontoIRPF.Text = "Desconto IRPF";
            // 
            // txtBDescontoINSS
            // 
            this.txtBDescontoINSS.Enabled = false;
            this.txtBDescontoINSS.Location = new System.Drawing.Point(441, 31);
            this.txtBDescontoINSS.Name = "txtBDescontoINSS";
            this.txtBDescontoINSS.Size = new System.Drawing.Size(164, 20);
            this.txtBDescontoINSS.TabIndex = 20;
            // 
            // txtBDescontoIRPF
            // 
            this.txtBDescontoIRPF.Enabled = false;
            this.txtBDescontoIRPF.Location = new System.Drawing.Point(441, 71);
            this.txtBDescontoIRPF.Name = "txtBDescontoIRPF";
            this.txtBDescontoIRPF.Size = new System.Drawing.Size(164, 20);
            this.txtBDescontoIRPF.TabIndex = 21;
            // 
            // grpBCasado
            // 
            this.grpBCasado.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.grpBCasado.Controls.Add(this.ckBCasado);
            this.grpBCasado.Location = new System.Drawing.Point(427, 148);
            this.grpBCasado.Name = "grpBCasado";
            this.grpBCasado.Size = new System.Drawing.Size(200, 80);
            this.grpBCasado.TabIndex = 11;
            this.grpBCasado.TabStop = false;
            // 
            // mTxtBSalarioBruto
            // 
            this.mTxtBSalarioBruto.Location = new System.Drawing.Point(173, 83);
            this.mTxtBSalarioBruto.Mask = "0000000.00";
            this.mTxtBSalarioBruto.Name = "mTxtBSalarioBruto";
            this.mTxtBSalarioBruto.Size = new System.Drawing.Size(164, 20);
            this.mTxtBSalarioBruto.TabIndex = 12;
            // 
            // cmBNumFilhos
            // 
            this.cmBNumFilhos.FormattingEnabled = true;
            this.cmBNumFilhos.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30"});
            this.cmBNumFilhos.Location = new System.Drawing.Point(173, 119);
            this.cmBNumFilhos.Name = "cmBNumFilhos";
            this.cmBNumFilhos.Size = new System.Drawing.Size(164, 21);
            this.cmBNumFilhos.TabIndex = 13;
            // 
            // btnVerifica
            // 
            this.btnVerifica.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerifica.Location = new System.Drawing.Point(188, 179);
            this.btnVerifica.Name = "btnVerifica";
            this.btnVerifica.Size = new System.Drawing.Size(133, 46);
            this.btnVerifica.TabIndex = 14;
            this.btnVerifica.Text = "Verificar Desconto";
            this.btnVerifica.UseVisualStyleBackColor = true;
            this.btnVerifica.Click += new System.EventHandler(this.btnVerifica_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(695, 507);
            this.Controls.Add(this.btnVerifica);
            this.Controls.Add(this.cmBNumFilhos);
            this.Controls.Add(this.mTxtBSalarioBruto);
            this.Controls.Add(this.grpBCasado);
            this.Controls.Add(this.grpBResultados);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.grpBSexo);
            this.Controls.Add(this.lblNumFilhos);
            this.Controls.Add(this.lblSalarioBruto);
            this.Controls.Add(this.lblFuncionario);
            this.Controls.Add(this.txtBFuncionario);
            this.Name = "Form1";
            this.Text = "Cálculo Salário Líquido";
            this.grpBSexo.ResumeLayout(false);
            this.grpBSexo.PerformLayout();
            this.grpBResultados.ResumeLayout(false);
            this.grpBResultados.PerformLayout();
            this.grpBCasado.ResumeLayout(false);
            this.grpBCasado.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtBFuncionario;
        private System.Windows.Forms.Label lblFuncionario;
        private System.Windows.Forms.Label lblSalarioBruto;
        private System.Windows.Forms.Label lblNumFilhos;
        private System.Windows.Forms.GroupBox grpBSexo;
        private System.Windows.Forms.RadioButton rdBtnMasculino;
        private System.Windows.Forms.RadioButton rdBtnFeminino;
        private System.Windows.Forms.CheckBox ckBCasado;
        private System.Windows.Forms.Label lblDados;
        private System.Windows.Forms.GroupBox grpBResultados;
        private System.Windows.Forms.TextBox txtBDescontoIRPF;
        private System.Windows.Forms.TextBox txtBDescontoINSS;
        private System.Windows.Forms.Label lblDescontoIRPF;
        private System.Windows.Forms.Label lblDescontoINSS;
        private System.Windows.Forms.TextBox txtSalarioLiquido;
        private System.Windows.Forms.TextBox txtSalarioFamilia;
        private System.Windows.Forms.TextBox txtBIRPF;
        private System.Windows.Forms.TextBox txtBINSS;
        private System.Windows.Forms.Label lblSalarioLiquido;
        private System.Windows.Forms.Label lblSalarioFamilia;
        private System.Windows.Forms.Label lblIRPF;
        private System.Windows.Forms.Label lblINSS;
        private System.Windows.Forms.GroupBox grpBCasado;
        private System.Windows.Forms.MaskedTextBox mTxtBSalarioBruto;
        private System.Windows.Forms.ComboBox cmBNumFilhos;
        private System.Windows.Forms.Button btnVerifica;
    }
}

