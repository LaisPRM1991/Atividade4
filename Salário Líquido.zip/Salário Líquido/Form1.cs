﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Salário_Líquido
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerifica_Click(object sender, EventArgs e)
        {
            lblDados.Visible = true;

            double descontoINSS = 0;
            double descontoIR = 0;
            double salarioFamilia = 0;
            double salarioLiquido = 0;
            double salarioBruto = 0;

            if ((txtBFuncionario.Text == "") || (txtBFuncionario.Text.Length < 5))
                MessageBox.Show("Nome inválido!");
            else if (double.TryParse(mTxtBSalarioBruto.Text, out salarioBruto))
            {
                //Cálculo do INSS
                if (salarioBruto <= 800.47)
                {
                    txtBINSS.Text = "7.65%";
                    descontoINSS = 0.0765 * salarioBruto;
                }
                else if (salarioBruto <= 1050)
                {
                    txtBINSS.Text = "8.65%";
                    descontoINSS = 0.0865 * salarioBruto;
                }
                else if (salarioBruto <= 1400.77)
                {
                    txtBINSS.Text = "9%";
                    descontoINSS = 0.09 * salarioBruto;
                }
                else if (salarioBruto <= 2801.56)
                {
                    txtBINSS.Text = "11%";
                    descontoINSS = 0.11 * salarioBruto;
                }
                else
                {
                    txtBINSS.Text = "Teto";
                    descontoINSS = 308.17;
                }
                txtBDescontoINSS.Text = Convert.ToString(descontoINSS);


                //Cálculo do IRPF
                if (salarioBruto <= 1257.12)
                {
                    txtBIRPF.Text = "Isento";
                    descontoIR = 0;
                }
                else if (salarioBruto <= 2512.08)
                {
                    txtBIRPF.Text = "15%";
                    descontoIR = 0.15 * salarioBruto;
                }
                else
                {
                    txtBIRPF.Text = "27.5%";
                    descontoIR = 0.275 * salarioBruto;
                }
                txtBDescontoIRPF.Text = Convert.ToString(descontoIR);


                //Cálculo do Salário Família
                if (salarioBruto <= 435.52)
                {
                    salarioFamilia = 22.33 * Convert.ToDouble(cmBNumFilhos.Text);
                }
                else if (salarioBruto <= 654.61)
                {
                    salarioFamilia = 15.74 * Convert.ToDouble(cmBNumFilhos.Text);
                }
                else
                {
                    salarioFamilia = 0;
                }
                txtSalarioFamilia.Text = Convert.ToString(salarioFamilia);


                //Cálculo do Salário Líquido
                salarioLiquido = salarioBruto - descontoINSS - descontoIR + salarioFamilia;
                txtSalarioLiquido.Text = Convert.ToString(salarioLiquido);


                //Montar mensagem no label
                lblDados.Text = "Os descontos do salário ";

                if (rdBtnFeminino.Checked)
                    lblDados.Text = lblDados.Text + "da Sra. " + txtBFuncionario.Text;
                else
                    lblDados.Text = lblDados.Text + "do Sr. " + txtBFuncionario.Text;

                lblDados.Text = lblDados.Text + " que é ";

                if (ckBCasado.Checked)
                    lblDados.Text = lblDados.Text + "casado(a) ";
                else
                    lblDados.Text = lblDados.Text + "solteiro(a) ";

                lblDados.Text = lblDados.Text + "e que tem " + cmBNumFilhos.Text + " filho(s) são: ";

            }
            else
                MessageBox.Show("Salário bruto inválido!");
        }
    }
}
